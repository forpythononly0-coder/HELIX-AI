# 04 UI Design

Placeholder for full specification.
