# 08 User Flow

Placeholder for full specification.
