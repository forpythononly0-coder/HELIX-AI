# 03 Folder Structure

Placeholder for full specification.
